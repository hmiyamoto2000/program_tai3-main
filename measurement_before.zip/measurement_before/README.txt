measurement_beforeに入れる画像の説明

preparation.pyにより補助線が書かれた画像(preparetion_afterに保存済)に以下の点を追加
・マゼンタの線上と鯛の体の上部分の輪郭が重なる部分　[R:254,G:254,B:0]
・マゼンタの線上と青の線上が重なる部分　[R:254,G:254,B:0]